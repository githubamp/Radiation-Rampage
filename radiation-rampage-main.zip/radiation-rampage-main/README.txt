Non-MacOS Preferred. If running into any issues please compile on WM CS Lab Machines.

1. Create a Debug folder by running the command "mkdir Debug"
2. Go into Debug folder "cd Debug"
3. Run the command "cmake .."
4. Run the command "make"
5. Run the executable "./main"
6. Enjoy the game!