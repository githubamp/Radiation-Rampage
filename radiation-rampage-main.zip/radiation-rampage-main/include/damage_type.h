#ifndef DAMAGE_TYPE_H
#define DAMAGE_TYPE_H

enum class DamageType {
    NORMAL,
    LASER,
    BOMB
};

#endif
